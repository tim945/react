import { CHANGE_FIRST_NAME, CHANGE_LAST_NAME } from "./action";

export function getInitialState() {
  return {
    firstName: "",
    lastName: "",
    token: ""
  };
}

export default (state = getInitialState(), action) => {
  const { type, payload } = action;
  switch (type) {
    case CHANGE_FIRST_NAME:
      return { ...state, firstName: payload };
    case CHANGE_LAST_NAME:
      return { ...state, lastName: payload };
    default:
      return state;
  }
};

