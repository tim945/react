import { createSelector } from "reselect";

// getter
const getCount = state => state.counter.count;

// selector
export const selectDoubleCount = createSelector(
  [getCount],
  count => count * 2
);
