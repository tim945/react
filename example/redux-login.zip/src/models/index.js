import  countReducer  from "./counter/reducer";
import  loginReducer  from "./login/reducer";
import  thunk  from "redux-thunk";
import { createStore, combineReducers, applyMiddleware } from "redux";


const store = createStore(combineReducers({
  counter:countReducer,
  login:loginReducer,
}), applyMiddleware(thunk));

export default store;