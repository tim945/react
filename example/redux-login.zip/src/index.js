import React from "react";
import ReactDOM from "react-dom";
import { Provider } from "react-redux";
import "./styles.css";
import store from "./models";
import LoginFn from "./LoginFn";
import LoginCls from "./LoginCls";

function App() {
  return (
    <div className="App">
      <LoginFn />
      <LoginCls />
    </div>
  );
}

ReactDOM.render(
  <Provider store={store}>
    <App />
  </Provider>,
  document.getElementById("root")
);
