import * as React from "react";
import { useSelector, useDispatch } from "react-redux";
import * as loginAction from "models/login/action";
import {
  selectFullName,
  selectNickName,
  selectAnotherNickName
} from "models/login/selector";

const Counter = () => {
  const { firstName, lastName } = useSelector(state => state.login);
  const fullName = useSelector(selectFullName);
  const nickName = useSelector(selectNickName);
  const anotherNickName = useSelector(selectAnotherNickName);
  const dispatch = useDispatch();
  const changeFirstName = (e) => dispatch(loginAction.changeFirstName(e.target.value));
  const asyncChangeFirstName = (e) => dispatch(loginAction.asyncChangeFirstName(e.target.value));
  const changeLastName = (e) => dispatch(loginAction.changeLastName(e.target.value));

  return (
    <>
      <h1>Fn Comp</h1>
      <div>
        firstName:
        <input value={firstName} onChange={changeFirstName} />
      </div>
      <div>
        async firstName:
        <input value={firstName} onChange={asyncChangeFirstName} />
      </div>
      <div>
        lastName:
        <input value={lastName} onChange={changeLastName} />
      </div>
      <div> fullName:{fullName}</div>
      <div> nickName:{nickName}</div>
      <div> anotherNickName:{anotherNickName}</div>
    </>
  );
};

export default Counter;
