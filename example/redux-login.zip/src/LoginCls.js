import React from "react";
import { connect } from "react-redux";
import * as loginAction from "models/login/action";
import {
  selectFullName,
  selectNickName,
  selectAnotherNickName
} from "models/login/selector";

@connect(
  state => ({
    firstName: state.login.firstName,
    lastName: state.login.lastName,
    fullName: selectFullName(state),
    nickName: selectNickName(state),
    anotherNickName: selectAnotherNickName(state),
  }), // mapStateToProps
  dispatch => ({
    // mapDispatchToProps
    changeFirstName: e =>
      dispatch(loginAction.changeFirstName(e.target.value)),
    asyncChangeFirstName: e =>
      dispatch(loginAction.asyncChangeFirstName(e.target.value)),
    changeLastName: e => dispatch(loginAction.changeLastName(e.target.value))
  })
)
class Counter extends React.Component {
  render() {
    const {
      firstName,
      lastName,
      fullName,
      nickName,
      anotherNickName,
      changeFirstName,
      asyncChangeFirstName,
      changeLastName
    } = this.props;
    return (
      <>
        <h1>Fn Comp</h1>
        <div>
          firstName:
          <input value={firstName} onChange={changeFirstName} />
        </div>
        <div>
          async firstName:
          <input value={firstName} onChange={asyncChangeFirstName} />
        </div>
        <div>
          lastName:
          <input value={lastName} onChange={changeLastName} />
        </div>
        <div> fullName:{fullName}</div>
        <div> nickName:{nickName}</div>
        <div> anotherNickName:{anotherNickName}</div>
      </>
    );
  }
}

export default Counter;
