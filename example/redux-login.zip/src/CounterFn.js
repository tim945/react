import * as React from "react";
import { useSelector, useDispatch } from "react-redux";
import * as counterAction from "models/counter/action";
import { selectDoubleCount } from "models/counter/selector";

const Counter = () => {
  const count = useSelector(state => state.counter.count);
  const doubleCount = useSelector(state => selectDoubleCount(state));
  const dispatch = useDispatch();
  const increase = () => dispatch(counterAction.increase(1));
  const decrease = () => dispatch(counterAction.decrease(1));

  return (
    <>
      <h1>Fn Count : {count}</h1>
      <h1>Fn doubleCount : {doubleCount}</h1>
      <button onClick={increase}>Increase</button>
      <button onClick={decrease}>decrease</button>
    </>
  );
};

export default Counter;
